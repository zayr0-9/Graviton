# hyper-router

A minimal **TypeScript agent runtime SDK** with pluggable providers, tools, and storage.

## Goal

The goal of this SDK is to provide a lightweight, plug-and-play agent runtime for Node.js and VM-style workloads.

It gives you:

- a built-in tool-call loop with agentic behavior
- multiple model providers behind one runtime contract
- multiple storage backends for transcript persistence and resume flows
- a small surface area so you can focus on your product instead of provider/runtime glue

`hyper-router` is intentionally minimal, but it still aims to give you flexibility in how you configure agents, models, providers, storage, and continuation strategies.

## Current status

What exists today:

- a core `AgentRuntime` with a built-in tool loop
- a small `ModelProvider` abstraction
- a transcript-first `StorageAdapter` abstraction
- built-in storage adapters:
  - `InMemoryStorage`
  - `JsonStorage`
  - `SqliteStorage`
  - `PostgresStorage`
- built-in providers:
  - `OpenRouterProvider`
  - `OpenAIVAIProvider`
  - `AmazonBedrockVAIProvider`
  - `AnthropicVAIProvider`
  - `GLMProvider`
  - `DeepSeekProvider`
- OpenRouter continuation modes:
  - `transcript`
  - `state`
  - `hybrid`
- transcript persistence and resume demos
- unit tests plus provider smoke scripts for local verification

What is not finished yet:

- additional storage backends beyond in-memory / JSON / SQLite / Postgres
- persistent OpenRouter native-state stores beyond the default in-memory implementation
- broader replay and continuation validation across more providers and models

## Getting started

Requirements:

- Node.js 20.3+ for the SDK (`AbortSignal.any`); Node.js 20.12+ for live smoke `.env` loading.

Install from npm:

```bash
npm install hyper-router
```

Optional adapter peer dependencies:

```bash
# OpenRouter provider
npm install hyper-router @openrouter/agent zod

# OpenAI VAI provider
npm install hyper-router ai @ai-sdk/openai

# Amazon Bedrock VAI provider
npm install hyper-router ai @ai-sdk/amazon-bedrock

# Anthropic VAI provider
npm install hyper-router ai @ai-sdk/anthropic

# DeepSeek provider
npm install hyper-router zod

# SQLite storage
npm install hyper-router sql.js

# Postgres storage
npm install hyper-router pg
```

Core APIs, `InMemoryStorage`, and `JsonStorage` are exported from the root package. Provider adapters and heavier storage adapters are exported from subpaths.

Minimal usage:

```ts
import { createRuntime, defineAgent, InMemoryStorage, StubProvider } from "hyper-router";

const agent = defineAgent({
  name: "example-agent",
  instructions: "You are helpful.",
  model: "stub-model",
});

const runtime = createRuntime({
  agent,
  provider: new StubProvider(),
  storage: new InMemoryStorage(),
});

const result = await runtime.run({
  sessionId: "demo-session",
  input: "Hello!",
});

console.log(result.status);
console.log(result.messages.at(-1));
```

### Hosted tools

Provider-executed hosted tools are **off by default**. Set `hostedTools: true` on the
agent or runtime for experimental opt-in. An explicit runtime value overrides the agent.
Local tools remain enabled through the existing tool configuration and permission policy.
See [Hosted tools](docs/hosted-tools.md) for enforcement and deferred replay/recovery support.

### Provider ownership and optional conversion

Runtimes bind one provider and model. Sessions persist provider ownership alongside their canonical content blocks. Incompatible history fails before model requests; foreign opaque data is not silently removed.

Persistent execution requires atomic owned-session storage. All built-in stores implement it. Custom adapters implement `historyIdentity`, `validateHistory`, and `generate`; direct calls with assistant/tool history must supply `historyOwnership`.

The optional `@hyper-labs/hyper-router/transcript-conversion` module supports customer converters and safe session forks. Its built-in `StubTranscriptConverter` rejects all pairs: there are no built-in translations. `TurnHandle.session` reports the effective session before execution. Reuse that destination for later turns.

See [Provider-owned sessions](docs/provider-owned-sessions.md) for configuration, custom converters, cancellation, storage locking, and idempotency. This breaking replacement remains under integration; older examples below are not yet all updated.

### Provider-native content

All provider responses can include `providerContent`, a provider/API-scoped record of ordered native messages or items and semantic metadata. The projected assistant message carries the same data for same-provider replay and transcript persistence. Unknown native fields remain in these records rather than being reduced to reasoning text.

This is **provider preparation**, not the full canonical content-block migration. Existing string content and separate tool-call fields remain a temporary runtime/display projection. VAI replay preserves the SDK message parts; original SDK output parts are also retained where the SDK's message conversion loses boundaries or output-only data. GLM/DeepSeek retain alternative choices but replay only the selected choice. Foreign provider history is rejected by default. Optional customer conversion must create a target-owned session before execution. Unsupported native parts remain captured; their acceptance by a provider on replay is not guaranteed.

Native content can contain sensitive reasoning and opaque continuation tokens. Do not print the carrier automatically. Transport headers and request credentials are not part of the capture. Modifying only flattened message text does not modify its native carrier; full block-based editing and validation are deferred to the content-block plan.

### Observable turn lifecycle

Public execution contracts (`AgentTurnInput`, `TurnHandle`, `TurnResult`, `ActiveTurnInfo`, `StepSummary`, `ModelAttemptSummary`, `ModelRetryContext`, and `ModelRetryPolicy`) are defined in `src/core/execution/types.ts` and exported from the package root. Import them with `import type { TurnResult } from "@hyper-labs/hyper-router"`. Execution orchestration helpers and their internal result/error types are not package-root exports; use `createRuntime()` to execute turns.

`run()` remains the aggregate convenience API. For streaming lifecycle events, use the same execution path through `startTurn()`:

```ts
const handle = runtime.startTurn({
  sessionId: "demo-session",
  turnId: "turn-123", // optional; generated when omitted
  input: "Use the available tools and explain the result.",
});

for await (const event of handle.events) {
  console.log(event.sequence, event.type);
}

const turn = await handle.result;
console.log(turn.status, turn.steps, turn.usage);
console.log(turn.startedAt, turn.finishedAt, turn.durationMs);
```

The lifecycle is `Turn → Step → Model Attempt → Tool Batch → Tool Execution`. Event sequences are monotonic within a turn. Existing aggregate providers continue to work; providers may additionally implement `StreamingModelProvider.stream(...)`. Runtime model retries stay within the same step through `modelRetry`, and tools default to exclusive execution unless marked `concurrency: "parallel"` with `maxParallelTools` configured.

`ActiveTurnInfo.startedAt` tracks admission time while a turn is active. Once settled, `TurnResult` includes `startedAt`, `finishedAt` (ISO timestamps), and `durationMs`. Live terminal events also include these fields under `data.timing`, including `turn.failed` when the result promise rejects. Timing uses the injected wall clock, includes input loading, model retries, tools, and transcript persistence, and stops before the terminal journal append; it excludes terminal-append latency and observer delivery. Negative elapsed time from a backward clock adjustment is clamped to zero. Crash-repair events omit timing because the actual execution finish time is unknown. Timing survives restart only when a durable lifecycle journal is configured; the active registry is not a history store.

Lifecycle events are live and non-durable by default. Supply a separate `LifecycleEventStore` to append durable lifecycle boundaries; transcript storage is configured separately.

Event payloads are isolated snapshots, not mutable views of the transcript. Payload data must be structured-cloneable. Transient deltas use a bounded lossy buffer. If a slow consumer exhausts `structuralEventBufferSize`, its event iterator throws `RuntimeEventBufferOverflowError` after draining the retained prefix. **The turn continues:** await `handle.result` for its outcome, or explicitly call `handle.cancel()` to stop it. With a journal configured, replay missed durable events through `LifecycleEventStore.read()`; transient deltas cannot be recovered. Handle event-stream errors separately from execution errors.

For crash recovery, stop all writers for the session and hold an application-level session lock. Call `repairInterruptedTurn({ store, sessionId, turnId, eventId })`, then `restoreTurnTranscript({ store, storage, sessionId, turnId })` before starting another turn. Recovery reconstructs the latest turn from its committed input and message/result events, synthesizes safe failures for unstarted tools, and preserves unknown external-effect outcomes without re-executing tools. `projectTurnTranscript(events, turnId)` exposes the transcript projection separately. Restoration refuses newer/interleaved turns or divergent stored history; the journal and base transcript adapters are not one atomic transaction.

For local development in this repository:

```bash
npm install
npm run check
npm test
npm run build
npm run dev
```

## Useful scripts

```bash
# quick demos
npm run demo:json-resume
npm run demo:sqlite-resume
npm run demo:openrouter:gpt54-mini
npm run demo:openrouter:gpt54-mini:sqlite

# OpenRouter smoke tests
npm run smoke:openrouter:text
npm run smoke:openrouter:tool
npm run smoke:openrouter:chain
npm run smoke:openrouter:runtime

# OpenAI VAI smoke tests
npm run smoke:openai:text
npm run smoke:openai:tool
npm run smoke:openai:chain

# Amazon Bedrock VAI smoke tests
npm run smoke:amazon-bedrock-vai:text
npm run smoke:amazon-bedrock-vai:tool
npm run smoke:amazon-bedrock-vai:chain
npm run smoke:amazon-bedrock-vai:runtime

# Anthropic VAI smoke tests
npm run smoke:anthropic-vai:text
npm run smoke:anthropic-vai:tool
npm run smoke:anthropic-vai:chain
npm run smoke:anthropic-vai:cache
npm run smoke:anthropic-vai:runtime
```

## Project structure

```txt
src/
  core/
    agent.ts
    providers.ts
    runtime.ts
    storage.ts
    tool.ts
    types.ts
  providers/
    amazon-bedrock-vai/
      index.ts
      provider.ts
      types.ts
    anthropic-vai/
      index.ts
      provider.ts
      types.ts
    openai-vai/
      index.ts
      provider.ts
      types.ts
    openrouter/
      index.ts
      items.ts
      provider.ts
      state.ts
      tool-output.ts
      types.ts
  storage/
    in-memory.ts
    json.ts
    sqlite.ts
    postgres.ts
    types.ts
    index.ts
  index.ts
examples/
  basic.ts
  json-resume-demo.ts
  sqlite-resume-demo.ts
  openrouter.ts
  openrouter-smoke.ts
  openrouter-tool-smoke.ts
  openrouter-tool-chain-smoke.ts
  openrouter-gpt54-mini-demo.ts
  openrouter-gpt54-mini-sqlite-demo.ts
  openai-smoke.ts
  openai-tool-smoke.ts
  openai-tool-chain-smoke.ts
  amazon-bedrock-vai.ts
  amazon-bedrock-vai-smoke.ts
  amazon-bedrock-vai-tool-smoke.ts
  amazon-bedrock-vai-tool-chain-smoke.ts
  anthropic-vai.ts
  anthropic-vai-smoke.ts
  anthropic-vai-tool-smoke.ts
  anthropic-vai-tool-chain-smoke.ts
  anthropic-vai-cache-smoke.ts
tests/
dist/
```

## Core concepts

- `defineAgent(...)` defines instructions, model, and tools
- `defineTool(...)` defines a callable tool
- `createRuntime(...)` wires agent + provider + storage together
- `ModelProvider` is the provider interface
- `StorageAdapter` is the current storage interface
- the canonical transcript is the durable conversation record
- provider reasoning/thinking output, when available, is stored on assistant messages as `message.reasoningContent`

## Basic example

```ts
import {
  createRuntime,
  defineAgent,
  defineTool,
  InMemoryStorage,
  StubProvider,
} from "hyper-router";

const echoTool = defineTool<{ text: string }, { echoed: string }>({
  name: "echo",
  description: "Echo text back.",
  async execute(args) {
    return {
      ok: true,
      output: {
        echoed: args.text,
      },
    };
  },
});

const agent = defineAgent({
  name: "example-agent",
  instructions: "You are helpful.",
  model: "stub-model",
  tools: [echoTool],
});

const runtime = createRuntime({
  agent,
  provider: new StubProvider(),
  storage: new InMemoryStorage(),
});
```

Run the basic example:

```bash
npx tsx examples/basic.ts
```

## Runtime cancellation

Turns can be cancelled either with a caller-owned `AbortController` or by using the runtime's active-turn registry. Use a stable `turnId` when your harness has parallel turns and needs to stop one specific turn.

```ts
const runtime = createRuntime({ agent, provider, storage });

const promise = runtime.run({
  sessionId: "session-1",
  turnId: "turn-abc123",
  input: "Do a long task",
});

// Stop only this in-process turn:
runtime.cancel("turn-abc123", { code: "user_requested", message: "User clicked Stop." });

const result = await promise;
console.log(result.status); // "cancelled"
```

`runtime.cancel()`, `runtime.cancelAll()`, and `handle.cancel()` accept a `CancellationReason` with a stable `code` (`user_requested`, `timeout`, `shutdown`, `superseded`, or `other`) and optional `message`. Omitting the reason defaults to `user_requested`. The first request wins. `cancel()` returns true only for a new cancellation request; `cancelAll()` counts only newly requested cancellations, excluding turns already aborted through a caller-owned signal. These return values do not mean execution has stopped.

Cancellation events preserve `{ code, message? }` at every lifecycle level. Caller-owned signals can carry arbitrary reasons: recognized structured reasons retain only their code/message, strings and errors become `other` with a message (`TimeoutError` becomes `timeout`), and unsupported values become `{ code: "other" }` without serializing arbitrary application data.

You can also pass a signal directly:

```ts
const controller = new AbortController();

const promise = runtime.run({
  sessionId: "session-1",
  input: "Do a long task",
  signal: controller.signal,
});

controller.abort("user clicked stop");
```

Cancellation is cooperative for local tools: tool `execute` functions receive `context.signal` and should stop promptly when it aborts. Built-in providers receive the same signal; providers that expose request abort support can stop the network call directly.

## Tool permissions

Tools can opt into host-mediated permission checks before execution. The runtime stays UI-neutral: it emits a structured permission request through hooks, and your app/harness decides how to ask the user.

```ts
const writeFileTool = defineTool<{ path: string; content: string }, { path: string }>({
  name: "write_file",
  description: "Write text to a local file.",
  permission: {
    mode: "ask",
    reason: "Writes to the filesystem.",
    metadata: { category: "filesystem" },
  },
  async execute(args) {
    // perform the write after permission is granted
    return { ok: true, output: { path: args.path } };
  },
});

const runtime = createRuntime({
  agent,
  provider,
  storage,
  hooks: {
    async requestToolPermission(request) {
      // Bridge this to a terminal modal, web dialog, JSON-lines sidecar, etc.
      // The request includes sessionId, step, toolCallId, toolName, args,
      // description, inputSchema, and optional tool metadata.
      const allowed = await askUserInYourHarness(request);
      return allowed ? { type: "allow" } : { type: "deny", reason: "User denied the request." };
    },
  },
});
```

Permission modes:

- omitted or `{ mode: "always" }` - execute normally
- `{ mode: "ask" }` - call `hooks.requestToolPermission(...)` before execution
- `{ mode: "never" }` - return a denied tool result without executing

You can also force a default policy for all tools from the runtime:

```ts
const runtime = createRuntime({
  agent,
  provider,
  storage,
  toolPermission: { defaultMode: "ask" },
  hooks: {
    requestToolPermission: async (request) => bridgeToHarness(request),
  },
});
```

If a tool explicitly asks for permission and no hook is configured, the runtime denies that tool call safely. Denials are recorded as normal `role: "tool"` results with the matching `toolCallId`, preserving transcript replay for providers.

## Tool call lifecycle hooks

Tool call lifecycle hooks are optional and protocol-neutral. If omitted, Hyper Router behaves exactly as before. Applications can use them to stream tool-call status to clients, collect telemetry, or bridge tool events into their own harness protocol.

```ts
const runtime = createRuntime({
  agent,
  provider,
  storage,
  hooks: {
    async onToolCallStart(event) {
      // Fired after permission is allowed and immediately before execute().
      // Includes sessionId, step, toolCallId, toolName, args, status, and startedAt.
      console.log("tool started", event.toolName, event.toolCallId);
    },
    async onToolCallFinish(event) {
      // Fired when a tool call resolves.
      // status is one of: completed, failed, denied, unknown_tool.
      // Successful/failed executions also include startedAt and durationMs.
      console.log("tool finished", event.status, event.result);
    },
  },
});
```

For registered tools that execute, the order is:

```txt
permission check, if configured -> onToolCallStart -> execute -> onToolCallFinish -> append role: "tool" message
```

For denied or unknown tool calls, `onToolCallStart` is not fired because no tool execution begins, but `onToolCallFinish` is fired with `status: "denied"` or `status: "unknown_tool"`. Lifecycle hooks are awaited; if a hook is best-effort telemetry, catch transport errors inside your hook.

## OpenRouter provider

This SDK includes an `OpenRouterProvider` implemented with `@openrouter/agent`.

Set your API key:

```bash
# PowerShell
$env:OPENROUTER_API_KEY="your_key_here"
```

Usage:

```ts
import { createRuntime, defineAgent, InMemoryStorage } from "hyper-router";
import { OpenRouterProvider } from "hyper-router/providers/openrouter";

const agent = defineAgent({
  name: "my-agent",
  instructions: "You are helpful.",
  model: "openai/gpt-5-mini",
});

const runtime = createRuntime({
  agent,
  provider: new OpenRouterProvider(),
  storage: new InMemoryStorage(),
});
```

Run the OpenRouter runtime example locally:

```bash
npx tsx examples/openrouter.ts
```

### OpenRouter image outputs

When an OpenRouter image-capable model returns a final generated image, the provider exposes it on `ModelResponse.generatedImages`.

Example shape:

```ts
const result = await provider.generate({
  model: "google/gemini-2.5-flash-image",
  messages: [
    {
      role: "user",
      content: "Generate a small pixel-art red square.",
      date: new Date(),
    },
  ],
  tools: [],
});

console.log(result.generatedImages);
// [
//   {
//     dataUrl: "data:image/png;base64,...",
//     mimeType: "image/png"
//   }
// ]
```

This library does **not** save image files for you. It only exposes the final image payload so your website/app can store it however you want.

A browser helper for converting a `dataUrl` into a `Blob`:

```ts
function dataUrlToBlob(dataUrl: string): Blob {
  const [header, base64] = dataUrl.split(",");
  if (!header || !base64) {
    throw new Error("Invalid data URL.");
  }

  const mimeType = /^data:([^;]+)/.exec(header)?.[1] ?? "application/octet-stream";
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);

  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }

  return new Blob([bytes], { type: mimeType });
}
```

Example upload flow in a website:

```ts
const image = result.generatedImages?.[0];

if (image?.dataUrl) {
  const blob = dataUrlToBlob(image.dataUrl);
  const file = new File([blob], `generated-${Date.now()}.png`, {
    type: image.mimeType ?? blob.type ?? "image/png",
  });

  const formData = new FormData();
  formData.append("file", file);

  await fetch("/api/uploads", {
    method: "POST",
    body: formData,
  });
}
```

If the upstream provider returns a remote image URL instead of a data URL, it will be exposed as `generatedImages[].url`.

### OpenRouter replay contract

For transcript-backed continuation, replay should follow this rule:

- **store messages as received**
- **send them back as stored**
- avoid unnecessary transformations during replay

Recent OpenRouter replay fixes in this repo include:

- assistant text is preserved on replay instead of being dropped
- tool outputs are replayed exactly as stored
- transcript replay no longer depends on `StateAccessor` for correctness

### Canonical transcript invariants

If you want transcript-only resume to remain correct and cache-sensitive, keep these stable:

- message ordering
- assistant text preservation
- assistant tool call ordering
- exact tool result payloads
- `toolCallId` linkage between assistant tool calls and tool outputs
- stable message grouping/boundaries where possible

## OpenRouter continuation modes

`OpenRouterProvider` now supports three continuation strategies:

### 1. `transcript`

- persists and resumes from the canonical transcript
- does **not** use OpenRouter `StateAccessor`
- reconstructs provider input from transcript on each call

Use this when you want:

- provider portability
- maximum transcript auditability
- minimal provider-specific persistence coupling

### 2. `state`

- uses OpenRouter-native `ConversationState` via `StateAccessor`
- resumes natively from provider state when available
- still relies on transcript persistence in the runtime today, but continuation behavior prefers native state

Use this when you want:

- OpenRouter-native continuity
- approval/interruption-friendly resume semantics
- provider-specific continuation behavior

### 3. `hybrid`

- keeps transcript persistence
- also keeps OpenRouter native state
- prefers native state when valid
- falls back to transcript replay when native state is missing or invalid

This is the recommended OpenRouter production mode when you want both:

- canonical transcript history
- provider-native continuation optimization

### Example configuration

Transcript only:

```ts
const provider = new OpenRouterProvider({
  continuation: {
    strategy: "transcript",
  },
});
```

Native OpenRouter state:

```ts
const provider = new OpenRouterProvider({
  continuation: {
    strategy: "state",
    stateStore,
  },
});
```

Hybrid:

```ts
const provider = new OpenRouterProvider({
  continuation: {
    strategy: "hybrid",
    stateStore,
    invalidateOnModelChange: true,
  },
});
```

If you provide a `stateStore` but omit `strategy`, the provider defaults to `hybrid`.
If you provide neither, it defaults to `transcript`.

## OpenRouter native state storage

When native state is enabled, the provider persists an OpenRouter state envelope through `OpenRouterStateStore`.

Conceptually it looks like:

```ts
interface OpenRouterStateStore {
  load(sessionId: string): Promise<OpenRouterStateEnvelope | null>;
  save(sessionId: string, envelope: OpenRouterStateEnvelope): Promise<void>;
  clear?(sessionId: string): Promise<void>;
}

interface OpenRouterStateEnvelope {
  state: ConversationState;
  metadata?: {
    model?: string;
    promptHash?: string;
    toolsetHash?: string;
  };
}
```

The envelope stores:

- the OpenRouter SDK `ConversationState`
- compatibility metadata used for invalidation checks

## OpenRouter invalidation rules

When `strategy` is `state` or `hybrid`, native state is checked against session metadata before reuse.

### Always invalidates native state on:

- `promptHash` change
- `toolsetHash` change

### Optionally invalidates native state on:

- `model` change

This is controlled by:

```ts
continuation: {
  invalidateOnModelChange: true; // default
}
```

If `invalidateOnModelChange` is `false`, model changes alone do not clear native state.

### On invalidation

The provider:

- clears native OpenRouter state
- falls back to transcript replay
- rebuilds fresh native state afterward through `StateAccessor`

## OpenRouter limitations right now

- the default native-state store is in-memory only unless you provide a persistent `OpenRouterStateStore`
- that means native continuation is not durable across process restarts or serverless cold starts unless you back it with your own store
- transcript/storage APIs are still early and will likely evolve
- transcript replay is faithful enough for current resume and cache probes, but it is not guaranteed to be byte-identical to opaque provider-native state in every provider/model path

## Storage backends

The runtime storage contract is pluggable and transcript-first.

The canonical transcript remains the durable source of truth across providers. Provider-native continuation state, such as OpenRouter `ConversationState`, is treated as an optional optimization layer rather than the primary conversation record.

Built-in adapters currently available:

- `InMemoryStorage` - process-local storage for tests/dev
- `JsonStorage` - durable single-file JSON storage
- `SqliteStorage` - durable SQLite-file storage
- `PostgresStorage` - durable Postgres-backed storage for shared deployments

All of them implement the same `StorageAdapter` contract:

- `loadMessages(sessionId)`
- `saveMessages(sessionId, messages)`
- `saveTurn(record)`
- optional `getSessionMetadata(sessionId)`
- optional `setSessionMetadata(sessionId, metadata)`

Session metadata remains optional in the storage contract, but it is used by OpenRouter native-state invalidation logic.

### Transcript semantics preserved by built-in adapters

The built-in storage backends preserve the same transcript behavior:

- system messages are filtered out on save
- message ordering is preserved
- `Date` values are restored on load
- tool calls and tool outputs round-trip as stored

### JSON example

```ts
import { JsonStorage } from "hyper-router";

const storage = new JsonStorage({
  filePath: "./tmp/agent-storage.json",
});
```

Run the JSON resume demo:

```bash
npm run demo:json-resume
```

### SQLite example

```ts
import { SqliteStorage } from "hyper-router/storage/sqlite";

const storage = new SqliteStorage({
  filePath: ".tmp/agent.sqlite",
});
```

Run the SQLite resume demo:

```bash
npm run demo:sqlite-resume
```

### Postgres example

```ts
import { PostgresStorage } from "hyper-router/storage/postgres";

const storage = new PostgresStorage({
  connectionString: process.env.DATABASE_URL,
});
```

`PostgresStorage` stores transcript messages, turn status, and session metadata in a single Postgres table using `jsonb` for transcript and metadata payloads.

### Developer context docs

Additional storage implementation notes live under:

- `docs/context/storage/README.md`
- `docs/context/storage/in-memory.md`
- `docs/context/storage/json.md`
- `docs/context/storage/sqlite.md`
- `docs/context/storage/postgres.md`
- `docs/context/storage/redis.md`

These docs capture the storage contract, canonical transcript invariants, and backend-specific guidance for current and future adapters.

## Real OpenRouter API smoke tests

These scripts hit the real OpenRouter API for manual integration testing.

Set your key first:

```bash
# PowerShell
$env:OPENROUTER_API_KEY="your_key_here"
```

Run the top-level smoke scripts:

```bash
npm run smoke:openrouter:text
npm run smoke:openrouter:tool
npm run smoke:openrouter:chain
npm run smoke:openrouter:runtime
```

What each script does:

- `smoke:openrouter:text` - verifies plain text generation works
- `smoke:openrouter:tool` - verifies the model emits a tool call for `echo(text)`
- `smoke:openrouter:chain` - runs transcript-resume and cache-oriented OpenRouter chain probes
- `smoke:openrouter:runtime` - runs the full runtime loop end to end and logs tool results

### `smoke:openrouter:chain` probe coverage

`examples/openrouter-tool-chain-smoke.ts` now includes multiple probes:

- **resume-transcript-tool-chain**  
  Starts a tool chain, persists transcript, creates a fresh runtime + fresh provider, and continues from transcript only.

- **cache-prefix-sensitivity**  
  Compares an exact repeated prefix against a reshaped-but-similar prefix to inspect cache sensitivity.

- **cache-state-accessor-tool-chain**  
  Uses one in-memory `StateAccessor` to inspect provider-native continuity behavior.

- **cache-transcript-shop-conversation** (`probe-d`)  
  Uses a realistic multi-turn tool-using agent conversation with a large stable system prompt to show cache reuse after transcript-only resume.

- **cache-transcript-shop-conversation-large-tool-output** (`probe-e`)  
  Uses a realistic multi-turn tool-using agent conversation with a small system prompt but a large persisted tool result to show cache reuse coming from transcripted tool history.

List the available chain probes:

```bash
npm run smoke:openrouter:chain -- --list
```

Run a single probe with the environment-variable selector:

```bash
# PowerShell
$env:OPENROUTER_SMOKE_ONLY="probe-d"
npm run smoke:openrouter:chain
```

You can also try npm argument forwarding:

```bash
npm run smoke:openrouter:chain -- --only=probe-e
```

If your shell/npm setup does not forward `--only=...` reliably, prefer `OPENROUTER_SMOKE_ONLY`.

## Current OpenRouter findings

From the current smoke and test work:

- transcript-only resume works semantically with a fresh runtime and fresh OpenRouter provider
- replay fidelity improved once assistant text and exact tool outputs were preserved
- OpenRouter cache usage is currently best read from `usage.inputTokensDetails.cachedTokens`
- exact prefix structure matters for visible cache reuse
- realistic transcript-only replay can preserve visible cache savings without `StateAccessor`
- both a large stable system prompt and a large persisted tool result can act as cacheable repeated prefix material

### Important caveat about cache results

Prompt cache behavior is provider/model dependent. A run showing `0` cached tokens is not automatically proof of replay failure. Visible cache reuse can vary with:

- provider routing
- cache thresholds or block sizing
- model behavior
- internal OpenRouter/provider decisions
- how much repeated stable prefix exists

## Publishing notes

This package layout is npm-friendly because:

- the package entrypoint exports library code only
- examples are kept separate from published source
- build output is isolated in `dist/`
- `prepublishOnly` runs typecheck, offline tests, and build before publish

## Reasoning content

Some providers/models can return reasoning or thinking content. When available, `hyper-router` stores it on assistant messages:

```ts
const result = await runtime.run({
  sessionId: "demo-session",
  input: "Solve this carefully.",
});

const assistant = result.messages.at(-1);
console.log(assistant?.content);
console.log(assistant?.reasoningContent);
```

Reasoning is optional, provider-dependent, and persists in storage with the rest of the transcript.

## GLM / Z.AI provider

```ts
import { GLMProvider } from "hyper-router/providers/glm";

const provider = new GLMProvider({
  thinking: { type: "enabled" },
});
```

The provider defaults to `https://api.z.ai/api/paas/v4/` and OpenAI-compatible chat mode. Set `ZAI_API_KEY`, pass `apiKey`, or override `baseURL`/`endpoint`.

When Z.AI returns `reasoning_content`, it is exposed as:

```ts
message.reasoningContent;
```

## DeepSeek provider

```ts
import { DeepSeekProvider } from "hyper-router/providers/deepseek";

const provider = new DeepSeekProvider({
  reasoning: { enabled: true, effort: "high" },
});
```

The provider defaults to `https://api.deepseek.com/` and OpenAI-compatible chat-completions mode. Set `DEEPSEEK_API_KEY`, pass `apiKey`, or override `baseURL`. Example smoke scripts use `DEEPSEEK_MODEL` when set and otherwise default to `deepseek-v4-pro`.

When DeepSeek returns `reasoning_content`, it is exposed as:

```ts
message.reasoningContent;
```

DeepSeek thinking mode with tool calls requires prior assistant `reasoning_content` to be replayed in subsequent requests. `DeepSeekProvider` includes stored `reasoningContent` on assistant replay by default when thinking is not disabled. Set `reasoning: false` or `reasoning: { includeInMessages: false }` only if you intentionally want to suppress reasoning replay.

### DeepSeek smoke tests

```bash
npm run smoke:deepseek:text
npm run smoke:deepseek:tool
npm run smoke:deepseek:chain
```

These scripts are intended for live API verification and require `DEEPSEEK_API_KEY`.

## OpenAI VAI provider

This SDK also includes an `OpenAIVAIProvider` implemented on top of the Vercel AI SDK using `ai` and `@ai-sdk/openai`.

Set your API key:

```bash
# PowerShell
$env:OPENAI_API_KEY="your_key_here"
```

Usage:

```ts
import { createRuntime, defineAgent, InMemoryStorage } from "hyper-router";
import { OpenAIVAIProvider } from "hyper-router/providers/openai-vai";

const agent = defineAgent({
  name: "my-openai-agent",
  instructions: "You are helpful.",
  model: "gpt-5-mini",
});

const runtime = createRuntime({
  agent,
  provider: new OpenAIVAIProvider(),
  storage: new InMemoryStorage(),
});
```

### OpenAI VAI provider architecture notes

The OpenAI VAI provider follows the same runtime-facing `ModelProvider` contract as `OpenRouterProvider`, but delegates model execution to Vercel AI SDK `generateText(...)`.

Important implementation details:

- canonical runtime messages are converted into AI SDK `ModelMessage[]`
- assistant tool calls are preserved as assistant `tool-call` content parts
- tool outputs are replayed as AI SDK `tool-result` message parts
- the provider reads assistant text back from `response.messages`
- model tool calls are normalized back into the SDK's `ToolCall[]` shape

### OpenAI VAI API selection

`OpenAIVAIProvider` supports selecting which Vercel OpenAI model factory to use:

- `auto` - uses `openai(model)`
- `responses` - uses `openai.responses(model)`
- `chat` - uses `openai.chat(model)`
- `completion` - uses `openai.completion(model)`

Example:

```ts
const provider = new OpenAIVAIProvider({
  api: "responses",
  providerOptions: {
    parallelToolCalls: false,
    store: false,
    user: "user_123",
  },
});
```

This maps directly to documented Vercel AI SDK OpenAI provider behavior, so if additional OpenAI provider options are needed later they should be passed through `providerOptions` rather than re-modeled in the runtime itself.

### OpenAI VAI smoke tests

```bash
npm run smoke:openai:text
npm run smoke:openai:tool
npm run smoke:openai:chain
```

These scripts are intended for live API verification and require `OPENAI_API_KEY`.

## Amazon Bedrock VAI provider

This SDK also includes an `AmazonBedrockVAIProvider` implemented on top of the Vercel AI SDK using `ai` and `@ai-sdk/amazon-bedrock`.

Set your AWS credentials and region:

```bash
# PowerShell
$env:AWS_REGION="us-east-1"
$env:AWS_ACCESS_KEY_ID="your_access_key"
$env:AWS_SECRET_ACCESS_KEY="your_secret_key"
```

You can also use Bedrock bearer-token auth or an AWS credential provider chain via provider options supported by `createAmazonBedrock(...)`.

Usage:

```ts
import { createRuntime, defineAgent, InMemoryStorage } from "hyper-router";
import { AmazonBedrockVAIProvider } from "hyper-router/providers/amazon-bedrock-vai";

const agent = defineAgent({
  name: "my-bedrock-agent",
  instructions: "You are helpful.",
  model: "meta.llama3-70b-instruct-v1:0",
});

const runtime = createRuntime({
  agent,
  provider: new AmazonBedrockVAIProvider({
    region: "us-east-1",
  }),
  storage: new InMemoryStorage(),
});
```

### Amazon Bedrock VAI provider architecture notes

The Bedrock VAI provider follows the same runtime-facing `ModelProvider` contract as the OpenRouter and OpenAI providers, while delegating model execution to Vercel AI SDK `generateText(...)` with `@ai-sdk/amazon-bedrock`.

Important implementation details:

- canonical runtime messages are converted into AI SDK `ModelMessage[]`
- assistant tool calls are preserved as assistant `tool-call` content parts
- tool outputs are replayed as AI SDK `tool-result` message parts
- the provider reads assistant text back from `response.messages`
- model tool calls are normalized back into the SDK's `ToolCall[]` shape
- Bedrock provider configuration is forwarded through `createAmazonBedrock(...)`
- Bedrock language-model provider options are forwarded under `providerOptions.bedrock`

### Amazon Bedrock VAI provider options

`AmazonBedrockVAIProvider` supports the documented Bedrock provider setup fields exposed by the Vercel AI SDK, including:

- `region`
- `apiKey`
- `accessKeyId`
- `secretAccessKey`
- `sessionToken`
- `credentialProvider`
- `baseURL`
- `headers`
- `fetch`
- `maxRetries`
- `providerOptions`

Example:

```ts
const provider = new AmazonBedrockVAIProvider({
  region: "us-east-1",
  providerOptions: {
    reasoningConfig: {
      type: "enabled",
      budgetTokens: 1024,
    },
  },
});
```

This maps directly to documented Vercel AI SDK Amazon Bedrock provider behavior, so additional Bedrock-specific request settings should be passed through `providerOptions` rather than re-modeled in the runtime itself.

### Amazon Bedrock VAI smoke tests

```bash
npm run smoke:amazon-bedrock-vai:text
npm run smoke:amazon-bedrock-vai:tool
npm run smoke:amazon-bedrock-vai:chain
npm run smoke:amazon-bedrock-vai:runtime
```

These scripts are intended for live API verification and require valid AWS Bedrock credentials.

A runtime-style example similar to the broader provider demos is also included at `examples/amazon-bedrock-vai.ts`.

## Anthropic VAI provider

This SDK also includes an `AnthropicVAIProvider` for calling the **Anthropic API directly** (not through Amazon Bedrock), implemented on top of the Vercel AI SDK using `ai` and `@ai-sdk/anthropic`.

Set your Anthropic API key:

```bash
# PowerShell
$env:ANTHROPIC_API_KEY="your_key_here"
```

Usage:

```ts
import { createRuntime, defineAgent, InMemoryStorage } from "hyper-router";
import { AnthropicVAIProvider } from "hyper-router/providers/anthropic-vai";

const agent = defineAgent({
  name: "my-anthropic-agent",
  instructions: "You are helpful.",
  model: "claude-3-5-sonnet-latest",
});

const runtime = createRuntime({
  agent,
  provider: new AnthropicVAIProvider(),
  storage: new InMemoryStorage(),
});
```

`AnthropicVAIProvider` supports the documented Anthropic provider setup fields exposed by the Vercel AI SDK: `apiKey`, `authToken` (for `Authorization: Bearer` auth), `baseURL`, `headers`, `fetch`, plus `maxRetries` and `providerOptions`. The API key is read from `ANTHROPIC_API_KEY` when `apiKey` is not passed.

### Anthropic VAI reasoning

Reasoning maps onto Anthropic's request options under `providerOptions.anthropic`:

- `reasoning: false` (or `{ enabled: false }`) → `thinking: { type: "disabled" }`
- `reasoning: { enabled: true }` → `thinking: { type: "enabled" }` (no token budget)
- `reasoning: { budgetTokens: 1024 }` → `thinking: { type: "enabled", budgetTokens: 1024 }`
- `reasoning: { effort: "high" }` → Anthropic's native top-level `effort` field (`"minimal"` falls back to `"low"`; a token budget is never fabricated from effort)

Unlike the OpenAI and Bedrock providers, prior assistant reasoning is **not replayed by default** (`includeInMessages` defaults to `false`). This is because the canonical transcript does not preserve Anthropic's cryptographic thinking-block signatures, and Anthropic rejects unsigned thinking blocks replayed with thinking enabled. Set `reasoning: { includeInMessages: true }` to opt in.

### Anthropic VAI prompt caching

Anthropic prompt caching is **not automatic** — it needs explicit `cache_control` breakpoints (max 4 per request; a breakpoint caches everything up to and including it, in the prefix order `tools → system → messages`, subject to a per-model token minimum of ~1024). `AnthropicVAIProvider` manages this for you and caching is **on by default**:

```ts
// Caching on (default): breakpoints on the system prefix + a rolling last-message breakpoint.
const provider = new AnthropicVAIProvider();

// Disable caching:
const provider = new AnthropicVAIProvider({ cache: false });

// Customize:
const provider = new AnthropicVAIProvider({
  cache: { system: true, tools: true, messages: true, ttl: "1h" },
});
```

Cache statistics are surfaced on the response so hits are verifiable:

```ts
const result = await provider.generate({ model, messages, tools });
console.log(result.usage?.cacheWriteTokens); // tokens written on a cache miss
console.log(result.usage?.cacheReadTokens); // tokens served from cache on a hit
```

### Anthropic VAI smoke tests

```bash
npm run smoke:anthropic-vai:text
npm run smoke:anthropic-vai:tool
npm run smoke:anthropic-vai:chain
npm run smoke:anthropic-vai:cache
```

These scripts are intended for live API verification and require `ANTHROPIC_API_KEY`. The `:cache` script runs two turns and asserts the second reads from cache. A runtime-style example is also included at `examples/anthropic-vai.ts`.
