# SDK documentation

These reference pages describe the current working-tree implementation, not a promise that every feature is release-ready.

## Agent and project context

The focused context guides live here in `docs/`. Paths in inline code and commands are repository-root-relative unless stated otherwise. The root [agent.md](../agent.md) and [AGENTS.md](../AGENTS.md) remain entry points for agent discovery.

- [Runtime context](./agent_runtime.md)
- [Storage context](./agent_storage.md)
- [Provider context](./agent_providers.md)
- [Testing context](./agent_testing.md)
- [Project context](./CONTEXT.md) — historical briefing; use current reference pages for current contracts.

## Current reference

- [Historical fix reconciliation](./historical-fix-reconciliation.md): restored pre-upgrade guarantees and deliberately superseded mechanisms.
- [Runtime privacy and turn persistence](./runtime-privacy-persistence.md): opt-in prompt snapshots and persisted lifecycle identity.
- [Tool cancellation hooks](./tool-cancellation-hooks.md): terminal hook semantics without synthetic transcript results.
- [Storage resilience](./storage-resilience.md): initialization retry, metadata validation, and temporary-file cleanup.
- [Provider regression port](./provider-regression-port.md): Bedrock effort normalization and safe cache/helper behavior.

- [Live smoke tests and local `.env` setup](./smoke-tests.md): real API commands, assertions, deadlines, and explicit validation limits.

- [Hosted tools](./hosted-tools.md): fixed agent/runtime opt-in, default-off enforcement and deferred support.

- [OpenRouter fidelity](./openrouter-fidelity.md): guarded native item groups and canonical-first state behavior.
- [Vercel provider fidelity](./vercel-provider-fidelity.md): pinned SDK ordering, reasoning, tools and media limits.
- [Direct chat fidelity](./direct-chat-fidelity.md): GLM/DeepSeek argument replay, thinking and endpoint handling.

- [Controlled streaming tests](./stream-testing.md): scripted fake provider, explicit pause gates, transition matrix, cancellation and retry checks.

- [Deterministic validation testing](./validation-testing.md): role matrices, fixed-seed round trips, resource boundaries, and current validation results.

- [Canonical content and provider codecs](./canonical-content.md): message blocks, tool results, media, native supplements, and adapter boundaries.
- [Provider API and SDK research](./provider-api-sdk-research.md): official wire contracts, replay constraints, media/tools/reasoning requirements, SDK version drift, and provider-specific test matrices.
- [Runtime lifecycle](./runtime-lifecycle.md): preparation, ownership, turns, attempts, streaming, cancellation, journaling, and recovery.
- [Provider-owned sessions](./provider-owned-sessions.md): fixed provider binding, custom adapters, optional conversion, rejecting stub, and session forks.
- [Storage overview](./context/storage/README.md): snapshot/CAS contracts and backend guarantees.
  - [In-memory](./context/storage/in-memory.md)
  - [JSON](./context/storage/json.md)
  - [SQLite](./context/storage/sqlite.md)
  - [Postgres](./context/storage/postgres.md)
  - [Redis proposal](./context/storage/redis.md) — not implemented.

## Design history and proposals

These documents preserve design context. They are not current API references:

- [Execution lifecycle migration plan](./execution-lifecycle-migration-plan.md)
- [SDK upgrades proposal](./hyper-router-upgrades.md)
- [Web integration proposal](./hyper-router-web-plan.md)

When a proposal conflicts with source-backed current reference pages, do not implement the proposal as if it were existing behavior.

## Implementation and validation limits

Latest historical-fix port validation: `npm run prepublishOnly` passes typecheck, **691 offline tests across 43 files**, and build. A built-artifact SQLite round trip also passes. All changed TypeScript files pass scoped Prettier/ESLint with ten complexity warnings and zero errors. Repository-wide ESLint still has 174 errors and 31 warnings; these are not hidden by the publication gate. The 75 added cases include regression-first privacy/identity/cancellation/backend/provider fixes and independent tests of retained equivalents. Review caught sql.js's internal initializer singleton, so the final locator/retry proof uses the actual installed module, not only mocks. See [reconciliation](./historical-fix-reconciliation.md).

Earlier migration snapshots below are historical validation records, not the latest totals.

The SDK uses canonical blocks, provider-owned snapshots, and an optional custom-converter interface. Built-in transcript conversion remains a rejecting stub. Regression fixtures and live smoke examples now use the current contracts.

The test-migration baseline had 197 failing and 396 passing tests. After migration and a serialized-journal date-rehydration fix, `npm test -- --reporter=dot` passes **603 tests across all 36 files**, without skipped or removed cases. The ten additional cases cover storage conflicts/legacy envelopes and recovery date validation/isolation. Source-only TypeScript checking passes. The subsequent smoke-example migration removes all 120 example diagnostics: **repository-wide `npm run check` now passes**. The unit suite including nine environment-helper tests and four OpenRouter cancellation regressions passes **616 tests across 37 files**, and `npm run build` passes. All six text commands were checked with credentials explicitly absent: each failed before requests with exit 1; these are preflight checks, not live passes. No real provider API keys were available. This is not a release-ready or live-provider guarantee.

Migration details and deliberately changed expectations:

- [Runtime events, tools, retries, cancellation and timing](./runtime-test-migration.md)
- [Runtime storage, continuation and CAS](./runtime-storage-test-migration.md)
- [Recovery crash boundaries and serialized dates](./recovery-test-migration.md)
- [Vercel/native provider fixtures](./vercel-test-migration.md)
- [Direct-chat and OpenRouter fixtures](./direct-provider-test-migration.md)
- [Storage backend fixtures](./context/storage/README.md#current-regression-fixtures)

`npm run build` passes. ESLint and Prettier pass for every changed/new test file; the modified recovery source has no lint errors (one existing complexity warning). Repository-wide ESLint still reports 178 errors and 27 warnings in untouched source/tests. Relative documentation file links and `git diff --check` pass. No live provider, external journal backend, multi-process durability, or Postgres service validation is implied.

Before releasing or reporting a code task complete, run the applicable checks and update this status from actual results. See the mandatory documentation procedure in [agent.md](../agent.md).
